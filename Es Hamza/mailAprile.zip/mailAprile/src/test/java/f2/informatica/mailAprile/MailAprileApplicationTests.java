package f2.informatica.mailAprile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailAprileApplicationTests {

	@Test
	void contextLoads() {
	}

}
