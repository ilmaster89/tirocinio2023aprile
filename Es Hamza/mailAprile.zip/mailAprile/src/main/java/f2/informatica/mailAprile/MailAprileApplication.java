package f2.informatica.mailAprile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailAprileApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailAprileApplication.class, args);
	}

}
