package f2.informatica.mailFromTemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailFromTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
