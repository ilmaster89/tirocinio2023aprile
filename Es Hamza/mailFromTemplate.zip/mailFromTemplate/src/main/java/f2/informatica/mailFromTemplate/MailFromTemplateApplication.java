package f2.informatica.mailFromTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailFromTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailFromTemplateApplication.class, args);
	}

}
