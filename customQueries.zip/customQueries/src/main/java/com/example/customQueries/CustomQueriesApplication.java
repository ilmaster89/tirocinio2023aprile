package com.example.customQueries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomQueriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomQueriesApplication.class, args);
	}

}
