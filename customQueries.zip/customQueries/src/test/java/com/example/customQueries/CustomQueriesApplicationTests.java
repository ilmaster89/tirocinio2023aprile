package com.example.customQueries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomQueriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
