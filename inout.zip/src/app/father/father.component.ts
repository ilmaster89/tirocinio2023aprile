import { Component } from '@angular/core';

@Component({
  selector: 'app-father',
  templateUrl: './father.component.html',
  styleUrls: ['./father.component.css']
})
export class FatherComponent {

  name?: string
  user?: any

  setName(name: string) {
    this.name = name
  }

  setSurname(event: any) {
    this.user = event
  }
}
