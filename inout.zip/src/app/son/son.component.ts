import { Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-son',
  templateUrl: './son.component.html',
  styleUrls: ['./son.component.css']
})
export class SonComponent {

  @Input() sonName?: string
  @Output() userEmitter: EventEmitter<any> = new EventEmitter<any>()

  ngOnChanges(changes: SimpleChanges): void {
    let newValue = changes["sonName"].currentValue
    sessionStorage.setItem("user", newValue)
  }

  setAnagrafica(cognome: string, eta: string) {
    this.userEmitter.emit({ cognome: cognome, eta: eta })
  }

}
