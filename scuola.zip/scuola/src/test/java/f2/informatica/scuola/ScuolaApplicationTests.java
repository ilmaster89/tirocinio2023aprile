package f2.informatica.scuola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScuolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
