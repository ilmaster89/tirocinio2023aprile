import { Component } from '@angular/core';
import * as L from 'leaflet';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent {

  map!: L.Map;
  circle!: L.Circle;
  circlesWithID: any[] = new Array()

  ngAfterViewInit(): void {
    this.map = L.map("map").setView([45.464664, 9.188540], 13)
    L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
      maxZoom: 20,
      attribution: '&copy; OpenStreetMap France | &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(this.map);

    let c1 = L.circle([45.462682, 9.188521], { radius: 500 })
    let c2 = L.circle([45.464666, 9.188543], { radius: 500 })

    c1.addTo(this.map)
    c2.addTo(this.map)

    this.circlesWithID.push({ id: 1, circle: c1 })
    this.circlesWithID.push({ id: 2, circle: c2 })

    L.circle([41.902782, 12.496366], { radius: 500 }).bindPopup("Questa è Roma!").addTo(this.map)
    
    
    this.map.on("click", (event) => {
      if (this.circle != null) {
        this.circle.removeFrom(this.map)
      }
      this.circle = L.circle(event.latlng, { radius: 500 })
      this.circle.addTo(this.map)
    })
  }

  eraseCircle(id: number) {
    this.circlesWithID.find((el) => { return el.id == id }).circle.removeFrom(this.map)
  }

  toRome() {
    this.map.flyTo([41.902782, 12.496366], 13)
  }
}
