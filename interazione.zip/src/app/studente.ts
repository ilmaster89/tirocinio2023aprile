export class Studente {

    id!: number
    nome!: string
    cognome!: string
    
}
