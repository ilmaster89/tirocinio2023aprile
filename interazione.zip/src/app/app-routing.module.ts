import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './form/form.component';
import { MainComponent } from './main/main.component';
import { SecondComponent } from './second/second.component';
import { SaveComponent } from './save/save.component';

const routes: Routes = [{
  path: "login", component: FormComponent
},
{ path: "main", component: MainComponent },
{ path: "second", component: SecondComponent },
{ path: "save", component: SaveComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
