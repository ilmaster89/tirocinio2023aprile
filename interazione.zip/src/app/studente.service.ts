import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Studente } from './studente';

@Injectable({
  providedIn: 'root'
})
export class StudenteService {

  constructor(private http: HttpClient) { }

  getStudenti(): Observable<Studente[]> {
    return this.http.get<Studente[]>("http://localhost:8080/list")
  }

  saveStudente(studente: Studente): Observable<number> {
    return this.http.post<number>("http://localhost:8080/save", studente)
  }

  getById(id: number): Observable<Studente> {
    return this.http.get<Studente>("http://localhost:8080/getById/" + id)
  }



}
