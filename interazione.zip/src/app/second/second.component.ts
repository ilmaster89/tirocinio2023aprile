import { Component } from '@angular/core';
import { StudenteService } from '../studente.service';
import { Studente } from '../studente';
import { Router } from '@angular/router';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent {

  studenti!: Studente[]
  nazioni!: any[]

  constructor(private service: StudenteService, private router: Router) { }

  ngOnInit() {
    this.service.getStudenti().subscribe(data => {
      this.studenti = data
      console.log("Nel subscribe: " + this.studenti)
    })
    console.log("Fuori dal subscribe: " + this.studenti)

  }

  modStudente(id: number) {
    sessionStorage.setItem("id", id.toFixed())
    this.router.navigateByUrl("save")
  }


}
