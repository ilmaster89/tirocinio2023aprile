import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'interazione';

  constructor(private router: Router) { }

  ngOnInit(): void {

    if (sessionStorage.getItem("user") != null || localStorage.getItem("user") != null) {
      let location = window.location.pathname
      console.log(location)
      if (location == "/") {
        this.router.navigateByUrl("main")
      } else {
        this.router.navigateByUrl(location)
      }
    } else {
      this.router.navigateByUrl("login")
    }

  }
}
