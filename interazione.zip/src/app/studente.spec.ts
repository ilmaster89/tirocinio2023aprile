import { Studente } from './studente';

describe('Studente', () => {
  it('should create an instance', () => {
    expect(new Studente()).toBeTruthy();
  });
});
