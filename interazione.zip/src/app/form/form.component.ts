import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {


  constructor(private router: Router) { }

  login(user: string, pass: string, remember: any): void {
    console.log(remember)
    if (remember == false) {
      sessionStorage.setItem("user", user)
    } else {
      localStorage.setItem("user", user)
    }

    this.router.navigateByUrl("main")
  }
}
