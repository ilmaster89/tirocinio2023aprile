import { Component } from '@angular/core';
import { Studente } from '../studente';
import { StudenteService } from '../studente.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-save',
  templateUrl: './save.component.html',
  styleUrls: ['./save.component.css']
})
export class SaveComponent {

  constructor(private service: StudenteService, private router: Router) { }

  studente: Studente = new Studente()

  ngOnInit(): void {
    if (sessionStorage.getItem("id") != null) {
      this.service.getById(sessionStorage.getItem("id") as any as number).subscribe(data => {
        this.studente = data
      })
    }
  }

  saveStudente(): void {
    this.service.saveStudente(this.studente).subscribe(data => {
      if (data == 0) {
        this.router.navigateByUrl("second")
      } else {
        window.location.reload()
      }
    })
  }
}
