package f2.informatica.encoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
