package f2.informatica.encoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncodingApplication.class, args);
	}

}
