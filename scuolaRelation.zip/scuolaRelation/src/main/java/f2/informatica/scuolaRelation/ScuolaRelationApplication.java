package f2.informatica.scuolaRelation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScuolaRelationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScuolaRelationApplication.class, args);
	}

}
